<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$host = 'sql212.infinityfree.com';
$db = 'if0_39160744_cotizaciones_fep';
$user = 'if0_39160744';
$pass = 'JxzKdCm7Lr2';
$charset = 'utf8mb4';

// Obtener datos del cuerpo de la solicitud
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validación básica de datos
if (!$data || !isset($data['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Datos de cotización no recibidos correctamente'
    ]);
    exit;
}

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    $pdo->beginTransaction();

    // 1. Guardar la nueva versión de la cotización
    $stmt = $pdo->prepare("INSERT INTO versiones_cotizaciones 
        (cotizacion_id, numero, datos) 
        VALUES (?, ?, ?)");
    
    $versionData = [
        'numero' => $data['numero'],
        'fecha' => $data['fecha'],
        'nombre_cliente' => $data['nombre_cliente'],
        'telefono_cliente' => $data['telefono_cliente'],
        'email_cliente' => $data['email_cliente'],
        'metodo_pago' => $data['metodo_pago'],
        'consideraciones' => $data['consideraciones'],
        'subtotal' => $data['subtotal'],
        'impuestos' => $data['impuestos'],
        'total' => $data['total'],
        'total_letras' => $data['total_letras'],
        'productos' => $data['productos']
    ];
    
    $stmt->execute([
        $data['id'],
        $data['numero'],
        json_encode($versionData)
    ]);
    
    $versionId = $pdo->lastInsertId();
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Versión de cotización guardada correctamente',
        'version_id' => $versionId
    ]);
    
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Error al guardar la versión',
        'error' => $e->getMessage()
    ]);
}
?>