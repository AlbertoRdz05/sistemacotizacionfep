<?php
// Configuración de la base de datos
$host = 'sql212.infinityfree.com';
$db = 'if0_39160744_cotizaciones_fep';
$user = 'if0_39160744';
$pass = 'JxzKdCm7Lr2';
$charset = 'utf8mb4';

// Obtener ID de la cotización
$id = $_GET['id'] ?? 0;

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Obtener información de la cotización
    $stmt = $pdo->prepare("SELECT * FROM cotizaciones WHERE id = ?");
    $stmt->execute([$id]);
    $cotizacion = $stmt->fetch();
    
    if (!$cotizacion) {
        die("Cotización no encontrada");
    }
    
    // Obtener productos de la cotización
    $stmt = $pdo->prepare("SELECT * FROM productos_cotizacion WHERE cotizacion_id = ?");
    $stmt->execute([$id]);
    $productos = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imprimir Cotización #<?= $cotizacion['numero'] ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            font-size: 12pt;
        }
        @page {
            size: auto;
            margin: 10mm;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            height: 80px;
            margin-right: 20px;
        }
        .title {
            font-size: 24px;
            color: green;
            font-weight: bold;
        }
        .info {
            text-align: right;
            font-size: 14px;
        }
        .info .numero {
            font-weight: bold;
            color: red;
        }
        .cliente-info {
            margin: 20px 0;
            width: 100%;
            border-collapse: collapse;
        }
        .cliente-info th {
            background-color: green;
            color: white;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            padding: 8px;
            text-align: left;
        }
        .cliente-info td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        #tabla-cotizacion {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        #tabla-cotizacion th, #tabla-cotizacion td {
            border: 1px solid #999;
            padding: 8px;
            text-align: left;
        }
        #tabla-cotizacion th {
            background-color: green;
            color: white;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .totales {
            margin-top: 20px;
            font-weight: bold;
        }
        .metodo-pago {
            margin-top: 20px;
        }
        .consideraciones {
            margin-top: 20px;
            width: 100%;
            border-collapse: collapse;
        }
        .consideraciones th {
            background-color: green;
            color: white;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            padding: 8px;
            text-align: left;
        }
        .consideraciones td {
            padding: 8px;
            border: 1px solid #ddd;
            font-style: italic;
        }
        .no-print {
            display: none !important;
        }
        .sucursales {
            text-align: center;
            color: green;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo fep.jpg" alt="Logo FEP">
            <div>
                <div class="title">COTIZACIÓN</div>
                <div>Vía Panamericana Tocumen</div>
                <div>E-mail: frioexpresspanama@gmail.com</div>
                <div>Tel: 6980-8086 / 295-6544</div>
                <div>Sitio Web: frioexpresspanama</div>
            </div>
        </div>
        <div class="info">
            <span>Nº: <span class="numero"><?= $cotizacion['numero'] ?></span></span>
            <span>FECHA: <?= $cotizacion['fecha'] ?></span>
        </div>
    </header>

    <!-- Datos del cliente -->
    <table class="cliente-info">
        <tr>
            <th colspan="2">COTIZACIÓN PARA</th>
        </tr>
        <tr>
            <td>NOMBRE:</td>
            <td><?= $cotizacion['cliente'] ?></td>
        </tr>
        <tr>
            <td>TEL:</td>
            <td><?= $cotizacion['telefono'] ?? 'N/A' ?></td>
        </tr>
        <tr>
            <td>EMAIL:</td>
            <td><?= $cotizacion['correo'] ?? 'N/A' ?></td>
        </tr>
    </table>

    <!-- Tabla principal de cotización -->
    <table id="tabla-cotizacion">
        <thead>
            <tr>
                <th>CANT</th>
                <th>DESCRIPCIÓN</th>
                <th>COSTO UNIT</th>
                <th>SUBTOTAL</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $producto): ?>
            <tr>
                <td><?= $producto['cantidad'] ?></td>
                <td><?= $producto['descripcion'] ?></td>
                <td>B/. <?= number_format($producto['costo'], 2) ?></td>
                <td>B/. <?= number_format($producto['subtotal'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">SUBTOTAL</td>
                <td>B/. <?= number_format($cotizacion['subtotal'], 2) ?></td>
            </tr>
            <tr>
                <td colspan="3">IMPUESTOS (7%)</td>
                <td>B/. <?= number_format($cotizacion['impuestos'], 2) ?></td>
            </tr>
            <tr>
                <td colspan="3">TOTAL</td>
                <td>B/. <?= number_format($cotizacion['total'], 2) ?></td>
            </tr>
            <tr>
                <td colspan="4">Cantidad en letras: <?= $cotizacion['total_letras'] ?? '' ?></td>
            </tr>
        </tfoot>
    </table>

    <!-- Método de pago -->
    <div class="metodo-pago">
        <strong>MÉTODO DE PAGO:</strong>
        <?php 
        $metodos = explode(", ", $cotizacion['metodo_pago'] ?? '');
        foreach ($metodos as $metodo): 
            if (!empty($metodo)):
        ?>
            <span><?= $metodo ?></span>
        <?php 
            endif;
        endforeach; 
        ?>
    </div>

    <!-- Tabla de Consideraciones (CORREGIDA) -->
    <table class="consideraciones">
        <tr>
            <th>CONSIDERACIONES</th>
        </tr>
        <tr>
            <td><?= !empty($cotizacion['consideraciones']) ? $cotizacion['consideraciones'] : '' ?></td>
        </tr>
    </table>
    
    <div class="sucursales">
        Sucursales: Chorrera, Coronado, Penonomé, Chitré y Santiago
    </div>

    <script>
        // Auto-imprimir al cargar la página
        window.onload = function() {
            setTimeout(function() {
                window.print();
                window.close();
            }, 200);
        };
    </script>
</body>
</html>