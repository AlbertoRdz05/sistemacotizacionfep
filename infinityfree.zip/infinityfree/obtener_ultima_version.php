<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$host = 'sql212.infinityfree.com';
$db = 'if0_39160744_cotizaciones_fep';
$user = 'if0_39160744';
$pass = 'JxzKdCm7Lr2';
$charset = 'utf8mb4';

$cotizacionId = $_GET['id'] ?? 0;

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Obtener la última versión de la cotización
    $stmt = $pdo->prepare("SELECT * FROM versiones_cotizaciones 
        WHERE cotizacion_id = ? 
        ORDER BY id DESC 
        LIMIT 1");
    
    $stmt->execute([$cotizacionId]);
    $version = $stmt->fetch();
    
    if (!$version) {
        echo json_encode([
            'success' => false,
            'message' => 'No se encontraron versiones para esta cotización'
        ]);
        exit;
    }

    // Decodificar los datos almacenados como JSON
    $datos = json_decode($version['datos'], true);

    if (!$datos) {
        echo json_encode([
            'success' => false,
            'message' => 'Error al decodificar los datos de la versión'
        ]);
        exit;
    }

    // Preparar la respuesta estructurada para facilitar el uso en JS
    echo json_encode([
        'success' => true,
        'version' => [
            'id' => $version['id'],
            'cotizacion_id' => $version['cotizacion_id'],
            'numero' => $datos['numero'],
            'fecha' => $datos['fecha'],
            'nombre_cliente' => $datos['nombre_cliente'] ?? '',
            'telefono_cliente' => $datos['telefono_cliente'] ?? '',
            'email_cliente' => $datos['email_cliente'] ?? '',
            'metodo_pago' => $datos['metodo_pago'] ?? '',
            'consideraciones' => $datos['consideraciones'] ?? '',
            'subtotal' => $datos['subtotal'] ?? 0,
            'impuestos' => $datos['impuestos'] ?? 0,
            'total' => $datos['total'] ?? 0,
            'total_letras' => $datos['total_letras'] ?? '',
            'productos' => $datos['productos'] ?? []
        ]
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error al obtener la versión',
        'error' => $e->getMessage()
    ]);
}
