<?php
header('Content-Type: application/json');
$conexion = new mysqli("sql212.infinityfree.com", "if0_39160744", "JxzKdCm7Lr2", "if0_39160744_cotizaciones_fep");
if ($conexion->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Error al conectar con la base de datos']);
    exit;
}

$sql = "SELECT * FROM cotizaciones ORDER BY fecha DESC";
$resultado = $conexion->query($sql);

$cotizaciones = [];

while ($row = $resultado->fetch_assoc()) {
    $id = $row['id'];

    // Revisar si hay versión más reciente
    $vsql = "SELECT datos FROM versiones_cotizaciones WHERE cotizacion_id = ? ORDER BY fecha_creacion DESC LIMIT 1";
    $stmt = $conexion->prepare($vsql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $vres = $stmt->get_result();

    if ($vres->num_rows > 0) {
        $vrow = $vres->fetch_assoc();
        $version = json_decode($vrow['datos'], true);
        $row['total'] = $version['total'];
    }

    $cotizaciones[] = $row;
}

echo json_encode([
    'success' => true,
    'quotations' => $cotizaciones
]);
?>
