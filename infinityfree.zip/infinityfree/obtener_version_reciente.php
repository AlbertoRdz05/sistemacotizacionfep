<?php
header('Content-Type: application/json');
$conexion = new mysqli("sql212.infinityfree.com", "if0_39160744", "JxzKdCm7Lr2", "if0_39160744_cotizaciones_fep");
if ($conexion->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión']);
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

// Obtener la versión más reciente
$sql = "SELECT datos FROM versiones_cotizaciones WHERE cotizacion_id = ? ORDER BY fecha_creacion DESC LIMIT 1";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'No se encontró ninguna versión']);
    exit;
}

$row = $result->fetch_assoc();
$data = json_decode($row['datos'], true);

echo json_encode([
    'success' => true,
    'cotizacion' => $data
]);
?>
