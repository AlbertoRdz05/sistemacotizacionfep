<?php
// Conexión a la base de datos
$conexion = new mysqli("sql212.infinityfree.com", "if0_39160744", "JxzKdCm7Lr2", "if0_39160744_cotizaciones_fep");
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Obtener la última versión de cotización
$sql = "SELECT * FROM versiones_cotizaciones ORDER BY fecha_creacion DESC LIMIT 1";
$resultado = $conexion->query($sql);

if ($resultado->num_rows === 0) {
    echo "No hay cotizaciones registradas.";
    exit;
}

$fila = $resultado->fetch_assoc();
$data = json_decode($fila['datos'], true);

function formato_moneda($valor) {
    return "B/. " . number_format((float)$valor, 2);
}

function convertirNumeroALetras($numero) {
    $unidades = ["CERO", "UNO", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE"];
    $decenas = ["", "", "VEINTE", "TREINTA", "CUARENTA", "CINCUENTA", "SESENTA", "SETENTA", "OCHENTA", "NOVENTA"];
    $especiales = [10 => "DIEZ", 11 => "ONCE", 12 => "DOCE", 13 => "TRECE", 14 => "CATORCE", 15 => "QUINCE", 16 => "DIECISÉIS", 17 => "DIECISIETE", 18 => "DIECIOCHO", 19 => "DIECINUEVE"];
    $entero = floor($numero);
    $decimal = round(($numero - $entero) * 100);
    if ($entero < 10) $letras = $unidades[$entero];
    elseif ($entero < 20) $letras = $especiales[$entero];
    elseif ($entero < 100) {
        $d = floor($entero / 10);
        $u = $entero % 10;
        $letras = $decenas[$d] . ($u > 0 ? " Y " . $unidades[$u] : "");
    } else $letras = $entero;
    return "$letras BALBOAS con $decimal/100";
}

$data['total_letras'] = convertirNumeroALetras(floatval($data['total']));

// Extraer solo los estilos del archivo HTML
$contenido_html = file_get_contents("cotizadorfep.html");
preg_match('/<style[^>]*>(.*?)<\/style>/is', $contenido_html, $coincidencias);
$estilos_css = $coincidencias[1] ?? '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Última Cotización</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <style><?= $estilos_css ?></style>
</head>
<body>

<div id="cotizacion-container">
  <header>
    <div class="logo">
      <img src="logo fep.jpg" alt="Logo FEP" />
      <div>
        <div class="title">COTIZACIÓN</div>
        <div>Vía Panamericana Tocumen</div>
        <div>E-mail: frioexpresspanama@gmail.com</div>
        <div>Tel: 6980-8086 / 295-6544</div>
        <div>Sitio Web: frioexpresspanama</div>
      </div>
    </div>
    <div class="info">
      <span>Nº: <span class="numero" id="cotizacion-numero"><?= htmlspecialchars($data['numero']) ?></span></span>
      <span>FECHA: <span id="cotizacion-fecha"><?= htmlspecialchars($data['fecha']) ?></span></span>
    </div>
  </header>

  <table class="cliente-info">
    <tr><th colspan="2">COTIZACIÓN PARA</th></tr>
    <tr><td>NOMBRE:</td><td><?= htmlspecialchars($data['nombre_cliente']) ?></td></tr>
    <tr><td>TEL:</td><td><?= htmlspecialchars($data['telefono_cliente']) ?></td></tr>
    <tr><td>EMAIL:</td><td><?= htmlspecialchars($data['email_cliente']) ?></td></tr>
  </table>

  <table id="tabla-cotizacion">
    <thead>
      <tr>
        <th>CANT</th>
        <th>DESCRIPCIÓN</th>
        <th>COSTO UNIT</th>
        <th>SUBTOTAL</th>
      </tr>
    </thead>
    <tbody id="contenido-tabla">
      <?php foreach ($data['productos'] as $prod): ?>
        <tr>
          <td><?= htmlspecialchars($prod['cantidad']) ?></td>
          <td><?= nl2br(htmlspecialchars($prod['descripcion'])) ?></td>
          <td><?= formato_moneda($prod['costo']) ?></td>
          <td><?= formato_moneda($prod['subtotal']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><td colspan="3">SUBTOTAL</td><td><?= formato_moneda($data['subtotal']) ?></td></tr>
      <tr><td colspan="3">IMPUESTOS (7%)</td><td><?= formato_moneda($data['impuestos']) ?></td></tr>
      <tr><td colspan="3">TOTAL</td><td><?= formato_moneda($data['total']) ?></td></tr>
      <tr><td colspan="4"><?= $data['total_letras'] ?></td></tr>
    </tfoot>
  </table>

  <div class="metodo-pago">
    <strong>MÉTODO DE PAGO:</strong>
    <?= htmlspecialchars($data['metodo_pago']) ?>
  </div>

  <table class="consideraciones">
    <tr><th>CONSIDERACIONES</th></tr>
    <tr><td><?= nl2br(htmlspecialchars($data['consideraciones'])) ?></td></tr>
  </table>

  <center><span style="color: green; font-weight: bold">Sucursales: Chorrera, Coronado, Penonomé, Chitré y Santiago</span></center>
</div>

<!-- Controles -->
<div class="controls" style="margin-top: 20px;">
  <button onclick="window.print()">Imprimir cotización</button>
  <button onclick="descargarPDF()">Descargar PDF</button>
</div>

<!-- Script para PDF -->
<script>
async function descargarPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF('p', 'pt', 'a4');
  const element = document.getElementById('cotizacion-container');

  // Capturar como imagen
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true
  });

  const imgData = canvas.toDataURL('image/png');
  const pdfWidth = doc.internal.pageSize.getWidth() - 40;
  const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

  doc.addImage(imgData, 'PNG', 20, 20, pdfWidth, pdfHeight);

  const numeroCotizacion = document.getElementById('cotizacion-numero').textContent.trim();
  const fecha = document.getElementById('cotizacion-fecha').textContent.trim();
  doc.save(`Cotizacion_${numeroCotizacion}_${fecha}.pdf`);
}
</script>

</body>
</html>
