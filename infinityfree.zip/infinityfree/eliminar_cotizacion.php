<?php
header('Content-Type: application/json');

$host = 'sql212.infinityfree.com';
$db = 'if0_39160744_cotizaciones_fep';
$user = 'if0_39160744';
$pass = 'JxzKdCm7Lr2';
$charset = 'utf8mb4';

$id = $_GET['id'] ?? 0;
$tipo = $_GET['tipo'] ?? 'original';

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    if ($tipo === 'original') {
        // Eliminar cotización original y sus versiones
        $stmt = $pdo->prepare("DELETE FROM cotizaciones WHERE id = ?");
        $stmt->execute([$id]);
        
        // Eliminar productos relacionados
        $stmt = $pdo->prepare("DELETE FROM productos_cotizacion WHERE cotizacion_id = ?");
        $stmt->execute([$id]);
        
        // Eliminar historial relacionado
        $stmt = $pdo->prepare("DELETE FROM cotizaciones_historial WHERE cotizacion_id = ?");
        $stmt->execute([$id]);
        
        // Eliminar productos del historial
        $stmt = $pdo->prepare("
            DELETE ph 
            FROM productos_cotizacion_historial ph
            JOIN cotizaciones_historial ch ON ph.cotizacion_historial_id = ch.id
            WHERE ch.cotizacion_id = ?
        ");
        $stmt->execute([$id]);
    } else {
        // Eliminar solo la versión del historial
        $stmt = $pdo->prepare("DELETE FROM cotizaciones_historial WHERE id = ?");
        $stmt->execute([$id]);
        
        // Eliminar productos del historial
        $stmt = $pdo->prepare("DELETE FROM productos_cotizacion_historial WHERE cotizacion_historial_id = ?");
        $stmt->execute([$id]);
    }
    
    echo json_encode(['success' => true]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de base de datos: ' . $e->getMessage()
    ]);
}
?>