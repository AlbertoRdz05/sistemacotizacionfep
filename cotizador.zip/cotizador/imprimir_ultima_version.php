<?php
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$conexion = new mysqli("localhost", "root", "", "cotizaciones_fep");
if ($conexion->connect_error || $id <= 0) {
    die("Error de conexión o ID inválido");
}

// Obtener la última versión
$sql = "SELECT datos FROM versiones_cotizaciones WHERE cotizacion_id = ? ORDER BY fecha_creacion DESC LIMIT 1";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Cotización no encontrada");
}

$row = $result->fetch_assoc();
$data = json_decode($row['datos'], true);

// Estilos desde cotizadorfep.html
$contenido_html = file_get_contents("cotizadorfep.html");
preg_match('/<style[^>]*>(.*?)<\/style>/is', $contenido_html, $coincidencias);
$estilos_css = $coincidencias[1] ?? '';

function formato_moneda($valor) {
    return "B/. " . number_format((float)$valor, 2);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cotización <?= htmlspecialchars($data['numero']) ?></title>
    <style><?= $estilos_css ?></style>
</head>
<body onload="window.print()">
    <header>
        <div class="logo">
            <img src="logo fep.jpg" alt="Logo FEP" />
            <div>
                <div class="title">COTIZACIÓN</div>
                <div>Vía Panamericana Tocumen</div>
                <div>E-mail: frioexpresspanama@gmail.com</div>
                <div>Tel: 6980-8086 / 295-6544</div>
                <div>Sitio Web: frioexpresspanama</div>
            </div>
        </div>
        <div class="info">
            <span>Nº: <span class="numero"><?= htmlspecialchars($data['numero']) ?></span></span>
            <span>FECHA: <span><?= htmlspecialchars($data['fecha']) ?></span></span>
        </div>
    </header>

    <table class="cliente-info">
        <tr><th colspan="2">COTIZACIÓN PARA</th></tr>
        <tr><td>NOMBRE:</td><td><?= htmlspecialchars($data['nombre_cliente']) ?></td></tr>
        <tr><td>TEL:</td><td><?= htmlspecialchars($data['telefono_cliente']) ?></td></tr>
        <tr><td>EMAIL:</td><td><?= htmlspecialchars($data['email_cliente']) ?></td></tr>
    </table>

    <table id="tabla-cotizacion">
        <thead>
            <tr>
                <th>CANT</th>
                <th>DESCRIPCIÓN</th>
                <th>COSTO UNIT</th>
                <th>SUBTOTAL</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data['productos'] as $prod): ?>
                <tr>
                    <td><?= htmlspecialchars($prod['cantidad']) ?></td>
                    <td><?= nl2br(htmlspecialchars($prod['descripcion'])) ?></td>
                    <td><?= formato_moneda($prod['costo']) ?></td>
                    <td><?= formato_moneda($prod['subtotal']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr><td colspan="3">SUBTOTAL</td><td><?= formato_moneda($data['subtotal']) ?></td></tr>
            <tr><td colspan="3">IMPUESTOS (7%)</td><td><?= formato_moneda($data['impuestos']) ?></td></tr>
            <tr><td colspan="3">TOTAL</td><td><?= formato_moneda($data['total']) ?></td></tr>
            <tr><td colspan="4"><?= htmlspecialchars($data['total_letras']) ?></td></tr>
        </tfoot>
    </table>

    <div class="metodo-pago">
        <strong>MÉTODO DE PAGO:</strong>
        <?= htmlspecialchars($data['metodo_pago']) ?>
    </div>

    <table class="consideraciones">
        <tr><th>CONSIDERACIONES</th></tr>
        <tr><td><?= nl2br(htmlspecialchars($data['consideraciones'])) ?></td></tr>
    </table>

    <center><span style="color: green; font-weight: bold">Sucursales: Chorrera, Coronado, Penonomé, Chitré y Santiago</span></center>
</body>
</html>
