<?php
// Configuración de la base de datos
$host = 'localhost';
$db = 'cotizaciones_fep';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Obtener ID de la cotización
$id = $_POST['id'] ?? 0;

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Obtener información de la cotización
    $stmt = $pdo->prepare("SELECT * FROM cotizaciones WHERE id = ?");
    $stmt->execute([$id]);
    $cotizacion = $stmt->fetch();
    
    if (!$cotizacion) {
        die("Cotización no encontrada");
    }
    
    // Obtener productos de la cotización
    $stmt = $pdo->prepare("SELECT * FROM productos_cotizacion WHERE cotizacion_id = ?");
    $stmt->execute([$id]);
    $productos = $stmt->fetchAll();
    
} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Cotización #<?= $cotizacion['numero'] ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #00A86B;
            color: white;
        }
        .totales {
            margin-top: 20px;
            font-weight: bold;
        }
        .btn {
            padding: 8px 15px;
            background-color: #00A86B;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>Frío Express Panamá</h1>
            <p>Cotización #<?= $cotizacion['numero'] ?></p>
            <p>Fecha: <?= $cotizacion['fecha'] ?></p>
        </div>
        <div>
            <p><strong>Cliente:</strong> <?= $cotizacion['cliente'] ?></p>
            <p><strong>Teléfono:</strong> <?= $cotizacion['telefono'] ?? 'N/A' ?></p>
            <p><strong>Email:</strong> <?= $cotizacion['correo'] ?? 'N/A' ?></p>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Cantidad</th>
                <th>Descripción</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($productos as $producto): ?>
            <tr>
                <td><?= $producto['cantidad'] ?></td>
                <td><?= $producto['descripcion'] ?></td>
                <td>B/. <?= number_format($producto['costo'], 2) ?></td>
                <td>B/. <?= number_format($producto['subtotal'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <div class="totales">
        <p>Subtotal: B/. <?= number_format($cotizacion['subtotal'], 2) ?></p>
        <p>Impuestos (7%): B/. <?= number_format($cotizacion['impuestos'], 2) ?></p>
        <p>Total: B/. <?= number_format($cotizacion['total'], 2) ?></p>
        <p>Total en letras: <?= $cotizacion['total_letras'] ?? '' ?></p>
    </div>
    
    <div class="consideraciones">
        <h3>Consideraciones:</h3>
        <p><?= $cotizacion['consideraciones'] ?? 'Ninguna' ?></p>
    </div>
    
    <a href="javascript:window.print()" class="btn">Imprimir Cotización</a>
    <a href="ver_cotizaciones.html" class="btn">Volver al Listado</a>
</body>
</html>