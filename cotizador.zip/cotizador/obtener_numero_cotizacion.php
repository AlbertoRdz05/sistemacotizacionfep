<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$host = 'localhost';
$db = 'cotizaciones_fep';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Obtener el último número de cotización
    $stmt = $pdo->query("SELECT MAX(numero) as last_number FROM cotizaciones");
    $result = $stmt->fetch();
    
    $lastNumber = $result['last_number'] ? (int)$result['last_number'] : 665;
    $nextNumber = $lastNumber + 1;
    
    echo json_encode([
        'success' => true,
        'nextNumber' => $nextNumber
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de base de datos: ' . $e->getMessage()
    ]);
}
?>