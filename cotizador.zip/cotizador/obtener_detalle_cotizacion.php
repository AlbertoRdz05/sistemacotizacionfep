<?php
header('Content-Type: application/json');

$host = 'localhost';
$db = 'cotizaciones_fep';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$id = $_GET['id'] ?? 0;
$es_original = $_GET['es_original'] ?? 1;

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    if ($es_original == 1) {
        // Obtener de la tabla original
        $stmt = $pdo->prepare("SELECT * FROM cotizaciones WHERE id = ?");
        $stmt->execute([$id]);
        $cotizacion = $stmt->fetch();
        
        // Obtener productos de la cotización original
        $stmt = $pdo->prepare("SELECT * FROM productos_cotizacion WHERE cotizacion_id = ?");
        $stmt->execute([$id]);
        $productos = $stmt->fetchAll();
    } else {
        // Obtener del historial
        $stmt = $pdo->prepare("SELECT * FROM cotizaciones_historial WHERE id = ?");
        $stmt->execute([$id]);
        $cotizacion = $stmt->fetch();
        
        // Obtener productos del historial
        $stmt = $pdo->prepare("SELECT * FROM productos_cotizacion_historial WHERE cotizacion_historial_id = ?");
        $stmt->execute([$id]);
        $productos = $stmt->fetchAll();
    }
    
    if (!$cotizacion) {
        echo json_encode([
            'success' => false,
            'message' => 'Cotización no encontrada'
        ]);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'cotizacion' => $cotizacion,
        'productos' => $productos
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de base de datos: ' . $e->getMessage()
    ]);
}
?>