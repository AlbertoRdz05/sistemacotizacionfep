<?php
// Activar errores (desactívalo en producción)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Conectar con la base de datos
$conexion = new mysqli("localhost", "root", "", "cotizaciones_fep");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Leer JSON enviado desde el formulario
$data = json_decode($_POST['json_data'], true);

// Verificar que llegó bien
if (!$data) {
    die("Datos no válidos o faltantes.");
}

// Extraer campos
$numero         = $conexion->real_escape_string($data['numero']);
$fecha          = $data['fecha'];
$cliente        = $conexion->real_escape_string($data['nombre_cliente']);
$telefono       = $conexion->real_escape_string($data['telefono_cliente']);
$correo         = $conexion->real_escape_string($data['email_cliente']);
$metodo_pago    = $conexion->real_escape_string($data['metodo_pago']);
$consideraciones = $conexion->real_escape_string($data['consideraciones']);
$subtotal       = floatval($data['subtotal']);
$impuestos      = floatval($data['impuestos']);
$total          = floatval($data['total']);
$total_letras   = $conexion->real_escape_string($data['total_letras']);
$productos      = $data['productos'];

// Guardar en tabla principal `cotizaciones`
$stmt = $conexion->prepare("INSERT INTO cotizaciones (numero, fecha, cliente, telefono, correo, metodo_pago, consideraciones, subtotal, impuestos, total, total_letras) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssdds", $numero, $fecha, $cliente, $telefono, $correo, $metodo_pago, $consideraciones, $subtotal, $impuestos, $total, $total_letras);
$exito = $stmt->execute();

if (!$exito) {
    die("Error al guardar cotización: " . $stmt->error);
}

$cotizacion_id = $stmt->insert_id;

// Guardar productos en `productos_cotizacion`
foreach ($productos as $prod) {
    $cantidad    = intval($prod['cantidad']);
    $descripcion = $conexion->real_escape_string($prod['descripcion']);
    $costo       = floatval($prod['costo']);
    $sub         = floatval($prod['subtotal']);

    $stmtProd = $conexion->prepare("INSERT INTO productos_cotizacion (cotizacion_id, cantidad, descripcion, costo, subtotal) VALUES (?, ?, ?, ?, ?)");
    $stmtProd->bind_param("iisdd", $cotizacion_id, $cantidad, $descripcion, $costo, $sub);
    $stmtProd->execute();
}

// Guardar copia JSON en `versiones_cotizaciones`
$jsonDatos = json_encode($data, JSON_UNESCAPED_UNICODE);
$stmtVer = $conexion->prepare("INSERT INTO versiones_cotizaciones (cotizacion_id, numero, datos) VALUES (?, ?, ?)");
$stmtVer->bind_param("iss", $cotizacion_id, $numero, $jsonDatos);
$stmtVer->execute();

// Redirigir a confirmación
header("Location: cotizacion_guardada.html?numero=" . urlencode($numero));
exit;
?>
