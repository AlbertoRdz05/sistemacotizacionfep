<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cotización Guardada</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .success-container {
            max-width: 600px;
            margin: 100px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            text-align: center;
            background-color: #fff;
        }
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        .btn-generate {
            margin-top: 20px;
            padding: 10px 25px;
        }
        .btn-back {
            margin-top: 15px;
            background-color: #6c757d;
            border-color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-container">
            <div class="success-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                </svg>
            </div>
            <h2 class="mb-3">¡Cotización guardada con éxito!</h2>
            <p class="lead">La cotización número <strong id="quote-number"></strong> ha sido almacenada correctamente en el sistema.</p>
        
                
                <button id="backToForm" class="btn btn-back btn-generate">
                    Volver al formulario
                </button>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Obtener el número de cotización de la URL
            const urlParams = new URLSearchParams(window.location.search);
            const quoteNumber = urlParams.get('numero');
            
            if (quoteNumber) {
                document.getElementById('quote-number').textContent = quoteNumber;
            }
            
            // Botón para volver al formulario
            document.getElementById('backToForm').addEventListener('click', function() {
                window.location.href = 'inicio.html';
            });
        });
    </script>
</body>
</html>