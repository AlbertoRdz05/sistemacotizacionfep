<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$host = 'localhost';
$db = 'cotizaciones_fep';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// Obtener número de cotización del parámetro GET
$numero = $_GET['numero'] ?? '';

try {
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];
    
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // 1. Buscar la cotización principal
    $stmt = $pdo->prepare("SELECT * FROM cotizaciones WHERE numero = ?");
    $stmt->execute([$numero]);
    $cotizacion = $stmt->fetch();
    
    if (!$cotizacion) {
        echo json_encode([
            'success' => false,
            'message' => 'No se encontró la cotización con el número proporcionado'
        ]);
        exit;
    }
    
    // 2. Buscar los productos asociados a esta cotización
    $stmt = $pdo->prepare("SELECT * FROM productos_cotizacion WHERE cotizacion_id = ?");
    $stmt->execute([$cotizacion['id']]);
    $productos = $stmt->fetchAll();
    
    // 3. Preparar respuesta con todos los datos
    echo json_encode([
        'success' => true,
        'cotizacion' => [
            'id' => $cotizacion['id'],
            'numero' => $cotizacion['numero'],
            'fecha' => $cotizacion['fecha'],
            // Campos del cliente con los nombres que espera el frontend
            'nombre_cliente' => $cotizacion['nombre'] ?? $cotizacion['cliente'] ?? '',
            'telefono_cliente' => $cotizacion['telefono'] ?? '',
            'email_cliente' => $cotizacion['email'] ?? '',
            'total' => $cotizacion['total'],
            'metodo_pago' => $cotizacion['metodo_pago'] ?? '',
            'consideraciones' => $cotizacion['consideraciones'] ?? '',
            'productos' => $productos
        ]
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de base de datos: ' . $e->getMessage()
    ]);
}
?>