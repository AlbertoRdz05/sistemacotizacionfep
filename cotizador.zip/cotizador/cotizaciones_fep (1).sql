-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-06-2025 a las 20:39:37
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cotizaciones_fep`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cotizaciones`
--

CREATE TABLE `cotizaciones` (
  `id` int(11) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `fecha` date NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `metodo_pago` varchar(255) DEFAULT NULL,
  `consideraciones` text DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `impuestos` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `total_letras` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `es_actual` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cotizaciones`
--

INSERT INTO `cotizaciones` (`id`, `numero`, `fecha`, `cliente`, `telefono`, `correo`, `metodo_pago`, `consideraciones`, `subtotal`, `impuestos`, `total`, `total_letras`, `created_at`, `es_actual`) VALUES
(3, '666', '2025-06-03', ' Sr. Saul F. Pdc Obarrio - Piso 20', '214-3669', 'ventas@durexproperty.com', 'Cheque', '', 260.00, 18.20, 278.20, 'Cantidad en letras: 278 BALBOAS con 20/100', '2025-06-03 21:43:56', 1),
(5, '667', '2025-06-04', 'hola', 'aaaa', 'dhjfjfsjf', 'Efectivo', '', 240.00, 16.80, 256.80, 'Cantidad en letras: 256 BALBOAS con 80/100', '2025-06-04 00:36:05', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cotizaciones_historial`
--

CREATE TABLE `cotizaciones_historial` (
  `id` int(11) NOT NULL,
  `cotizacion_id` int(11) NOT NULL,
  `numero` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `cliente` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `impuestos` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `total_letras` varchar(255) DEFAULT NULL,
  `consideraciones` text DEFAULT NULL,
  `version` int(11) NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_cotizacion`
--

CREATE TABLE `productos_cotizacion` (
  `id` int(11) NOT NULL,
  `cotizacion_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `costo` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos_cotizacion`
--

INSERT INTO `productos_cotizacion` (`id`, `cotizacion_id`, `cantidad`, `descripcion`, `costo`, `subtotal`) VALUES
(3, 3, 1, 'Servicio de mantenimiento de 6 unidades de aire acondicionado, 3 tipo fancoil, \n2 tipo casette y 1 tipo central', 260.00, 260.00),
(5, 5, 2, 'jhkfhkjfshjfshjfshj', 120.00, 240.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos_cotizacion_historial`
--

CREATE TABLE `productos_cotizacion_historial` (
  `id` int(11) NOT NULL,
  `cotizacion_historial_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `costo` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `versiones_cotizaciones`
--

CREATE TABLE `versiones_cotizaciones` (
  `id` int(11) NOT NULL,
  `cotizacion_id` int(11) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `datos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`datos`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `versiones_cotizaciones`
--

INSERT INTO `versiones_cotizaciones` (`id`, `cotizacion_id`, `numero`, `fecha_creacion`, `datos`) VALUES
(1, 3, '666', '2025-06-04 15:02:41', '{\"numero\":\"666\",\"fecha\":\"2025-06-03\",\"nombre_cliente\":\" Sr. Saul F. Pdc Obarrio - Piso 20\",\"telefono_cliente\":\"214-3669\",\"email_cliente\":\"\",\"metodo_pago\":\"Cheque\",\"consideraciones\":\"\",\"subtotal\":\"780.00\",\"impuestos\":\"54.60\",\"total\":\"834.60\",\"total_letras\":\"Cantidad en letras: 834 BALBOAS con 60\\/100\",\"productos\":[{\"cantidad\":3,\"descripcion\":\"Servicio de mantenimiento de 6 unidades de aire acondicionado, 3 tipo fancoil, \\n2 tipo casette y 1 tipo central\",\"costo\":260,\"subtotal\":780}]}'),
(2, 5, '667', '2025-06-04 16:54:09', '{\"numero\":\"667\",\"fecha\":\"2025-06-04\",\"nombre_cliente\":\"hola\",\"telefono_cliente\":\"aaaa\",\"email_cliente\":\"\",\"metodo_pago\":\"Efectivo\",\"consideraciones\":\"\",\"subtotal\":\"1080.00\",\"impuestos\":\"75.60\",\"total\":\"1155.60\",\"total_letras\":\"Cantidad en letras: 1155 BALBOAS con 60\\/100\",\"productos\":[{\"cantidad\":9,\"descripcion\":\"jhkfhkjfshjfshjfshj\",\"costo\":120,\"subtotal\":1080}]}'),
(3, 5, '667', '2025-06-04 18:03:34', '{\"numero\":\"667\",\"fecha\":\"2025-06-04\",\"nombre_cliente\":\"hola\",\"telefono_cliente\":\"aaaa\",\"email_cliente\":\"\",\"metodo_pago\":\"Efectivo\",\"consideraciones\":\"\",\"subtotal\":\"960.00\",\"impuestos\":\"67.20\",\"total\":\"1027.20\",\"total_letras\":\"Cantidad en letras: 1027 BALBOAS con 20\\/100\",\"productos\":[{\"cantidad\":8,\"descripcion\":\"jhkfhkjfshjfshjfshj\",\"costo\":120,\"subtotal\":960}]}'),
(4, 5, '667', '2025-06-04 18:08:27', '{\"numero\":\"667\",\"fecha\":\"2025-06-04\",\"nombre_cliente\":\"hola\",\"telefono_cliente\":\"aaaa\",\"email_cliente\":\"\",\"metodo_pago\":\"Efectivo\",\"consideraciones\":\"\",\"subtotal\":\"1440.00\",\"impuestos\":\"100.80\",\"total\":\"1540.80\",\"total_letras\":\"Cantidad en letras: 1540 BALBOAS con 80\\/100\",\"productos\":[{\"cantidad\":12,\"descripcion\":\"jhkfhkjfshjfshjfshj\",\"costo\":120,\"subtotal\":1440}]}'),
(5, 5, '667', '2025-06-04 18:21:14', '{\"numero\":\"667\",\"fecha\":\"2025-06-04\",\"nombre_cliente\":\"hola\",\"telefono_cliente\":\"aaaa\",\"email_cliente\":\"\",\"metodo_pago\":\"Efectivo\",\"consideraciones\":\"\",\"subtotal\":\"1560.00\",\"impuestos\":\"109.20\",\"total\":\"1669.20\",\"total_letras\":\"Cantidad en letras: 1669 BALBOAS con 20\\/100\",\"productos\":[{\"cantidad\":13,\"descripcion\":\"jhkfhkjfshjfshjfshj\",\"costo\":120,\"subtotal\":1560}]}'),
(6, 3, '666', '2025-06-04 18:21:51', '{\"numero\":\"666\",\"fecha\":\"2025-06-03\",\"nombre_cliente\":\" Sr. Saul F. Pdc Obarrio - Piso 20\",\"telefono_cliente\":\"214-3669\",\"email_cliente\":\"\",\"metodo_pago\":\"Cheque\",\"consideraciones\":\"\",\"subtotal\":\"1040.00\",\"impuestos\":\"72.80\",\"total\":\"1112.80\",\"total_letras\":\"Cantidad en letras: 1112 BALBOAS con 80\\/100\",\"productos\":[{\"cantidad\":4,\"descripcion\":\"Servicio de mantenimiento de 6 unidades de aire acondicionado, 3 tipo fancoil, \\n2 tipo casette y 1 tipo central\",\"costo\":260,\"subtotal\":1040}]}'),
(7, 3, '666', '2025-06-04 18:22:53', '{\"numero\":\"666\",\"fecha\":\"2025-06-03\",\"nombre_cliente\":\" Sr. Saul F. Pdc Obarrio - Piso 20\",\"telefono_cliente\":\"214-3669\",\"email_cliente\":\"\",\"metodo_pago\":\"Cheque\",\"consideraciones\":\"\",\"subtotal\":\"1040.00\",\"impuestos\":\"72.80\",\"total\":\"1112.80\",\"total_letras\":\"Cantidad en letras: 1112 BALBOAS con 80\\/100\",\"productos\":[{\"cantidad\":4,\"descripcion\":\"Servicio de mantenimiento de 6 unidades de aire acondicionado, 3 tipo fancoil, \\n2 tipo casette y 1 tipo central\",\"costo\":260,\"subtotal\":1040}]}');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cotizaciones`
--
ALTER TABLE `cotizaciones`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `numero` (`numero`);

--
-- Indices de la tabla `cotizaciones_historial`
--
ALTER TABLE `cotizaciones_historial`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cotizacion_id` (`cotizacion_id`);

--
-- Indices de la tabla `productos_cotizacion`
--
ALTER TABLE `productos_cotizacion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cotizacion_id` (`cotizacion_id`);

--
-- Indices de la tabla `productos_cotizacion_historial`
--
ALTER TABLE `productos_cotizacion_historial`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cotizacion_historial_id` (`cotizacion_historial_id`);

--
-- Indices de la tabla `versiones_cotizaciones`
--
ALTER TABLE `versiones_cotizaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cotizacion_id` (`cotizacion_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cotizaciones`
--
ALTER TABLE `cotizaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `cotizaciones_historial`
--
ALTER TABLE `cotizaciones_historial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos_cotizacion`
--
ALTER TABLE `productos_cotizacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `productos_cotizacion_historial`
--
ALTER TABLE `productos_cotizacion_historial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `versiones_cotizaciones`
--
ALTER TABLE `versiones_cotizaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cotizaciones_historial`
--
ALTER TABLE `cotizaciones_historial`
  ADD CONSTRAINT `cotizaciones_historial_ibfk_1` FOREIGN KEY (`cotizacion_id`) REFERENCES `cotizaciones` (`id`);

--
-- Filtros para la tabla `productos_cotizacion`
--
ALTER TABLE `productos_cotizacion`
  ADD CONSTRAINT `productos_cotizacion_ibfk_1` FOREIGN KEY (`cotizacion_id`) REFERENCES `cotizaciones` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `productos_cotizacion_historial`
--
ALTER TABLE `productos_cotizacion_historial`
  ADD CONSTRAINT `productos_cotizacion_historial_ibfk_1` FOREIGN KEY (`cotizacion_historial_id`) REFERENCES `cotizaciones_historial` (`id`);

--
-- Filtros para la tabla `versiones_cotizaciones`
--
ALTER TABLE `versiones_cotizaciones`
  ADD CONSTRAINT `versiones_cotizaciones_ibfk_1` FOREIGN KEY (`cotizacion_id`) REFERENCES `cotizaciones` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
